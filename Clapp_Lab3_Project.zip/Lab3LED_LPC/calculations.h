
// function prototypes which relate to calculations
int compute_sum(int, int);  
int compute_difference(int, int);


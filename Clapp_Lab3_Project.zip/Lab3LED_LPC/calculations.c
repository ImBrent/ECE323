
#include "calculations.h"

int compute_sum(int x, int y)
{
	int sum = 0;
	sum = x + y;
	return sum;
}


int compute_difference(int x, int y)
{
	int difference = 0;
	difference = x - y;
	return difference;
}


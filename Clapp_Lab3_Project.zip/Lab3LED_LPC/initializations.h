
// this function returns nothing (void)
// and the function recieves no parameters(void)
void initialize_P4P6(void);

// a flag is passed in so we know to make the pin high or make it low
void toggle_pin(char);

//Header for Level 2's function calls
char test_pin17(void);
void set_pin1(char flag);
